import { Component, OnInit } from '@angular/core';
import { ExpenseService } from '../service/expense.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Expense } from '../model/expense';

@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {

  searchedExpense: Expense;
  searchFound: boolean =  false;
  flag: boolean = true;
  constructor(private expenseService: ExpenseService, private router: Router, private http: HttpClient) { }

  ngOnInit() {
  }

//Add this filterData
  filterData(value: number) {
    this.expenseService.searchExpense(value).subscribe((data: Expense) => {
      this.searchedExpense = data;
      if (this.searchedExpense != null) {
        this.searchFound = true;
      } else {
        this.searchFound = false;
        alert('Data not found');
      }
    });

  }
//set searchFound to false
  deleteData(value: number) {
    this.expenseService.deleteExpense(value).subscribe((data: Expense) => {
      this.searchedExpense = data;
      if (this.searchedExpense != null) {
        this.searchFound = false;
        alert('Data deleted successfully!');
      } else {
        this.searchFound = false;
        alert('Data not found!');
      }

    });
  
  }

}
