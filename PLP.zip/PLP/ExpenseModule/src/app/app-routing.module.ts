import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DisplayallComponent } from './displayall/displayall.component';
import { AddExpenseComponent } from './add-expense/add-expense.component';
import { UpdateExpenseComponent } from './update-expense/update-expense.component';
import { SearchComponent } from './search/search.component';
import { DeleteComponent } from './delete/delete.component';
import { UpdateuiComponent } from './updateui/updateui.component';


const routes: Routes = [
  { path: '', redirectTo: 'displayall', pathMatch: 'full'},
  { path: 'displayall', component: DisplayallComponent},
  { path: 'add', component: AddExpenseComponent},
  { path: 'update', component: UpdateExpenseComponent},
  { path: 'updateui', component: UpdateuiComponent},
  { path: 'search', component: SearchComponent},
  { path: 'delete', component: DeleteComponent}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
