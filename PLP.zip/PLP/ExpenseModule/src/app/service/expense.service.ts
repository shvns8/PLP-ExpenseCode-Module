import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Expense } from '../model/expense';
import { throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class ExpenseService {
  expenses: Expense[];
  expenses1: Expense;
  updateExp: Expense;//Add this element
  status: string;
  filteredData: Expense[];
  index: number;
  expense: Expense;
  searchedExpense: Expense;
  constructor(private http: HttpClient) {
    this.getExpenses();
    this.http.get<Expense[]>('http://localhost:8083/ExpenseCode/displayall/').subscribe((data: Expense[]) => {
      this.expenses = data;

    });
  }
  getData(): Observable<Expense[]> {
    return this.http.get<Expense[]>('http://localhost:8083/ExpenseCode/displayall/');

  }
  getExpenses() {
    this.getData().subscribe((data: Expense[]) => {
      this.expenses = data;

    });
    return this.expenses;
  }
  handlError(error) {
    console.log(error);
    return throwError;
  }
  getAllExpenses() {
    return this.expenses;
  }

  //start
  getUpdateExp() {
    return this.updateExp;
  }
  setUpdateExp(exp:Expense) {
    this.updateExp = exp;
  }

  //End
  setExpenses(expen) {
    this.expenses.push(expen);
  }
  getAddExpenses() {
    return this.expenses;
  }
  addExpense(exp: Expense): any {
    let obj = this.http.post('http://localhost:8083/ExpenseCode/add/', exp)

    return obj;
  }

  getSearchedExpense() {
    return this.searchedExpense;
  }
  setSearchedExpense(exp: Expense) {
    this.searchedExpense = exp;
  }
  getSearchedData() {
    return this.filteredData;
  }
  deleteExpense(i: number) {
    return this.http.delete('http://localhost:8083/ExpenseCode/delete/' + i);
  }
  setIndex(i) {
    this.index = i;
  }
  getIndex() {
    return this.index;
  }
  getExpense(i) {
    return this.expenses[i];
  }
  updateExpense(exp: Expense): Expense {

    this.http.put('http://localhost:8083/ExpenseCode/update/' + exp.expenseCode, exp).subscribe((data: Expense) => {
      this.expenses1 = data;
    });
    // this.expenses[this.expenses.indexOf(exp)] = this.expenses1;
    return this.expenses1;
  }
  searchExpense(code: number): any {
    let obj = this.http.get<Expense>('http://localhost:8083/ExpenseCode/displayExpDet/' + code);
    return obj;
  }
}
